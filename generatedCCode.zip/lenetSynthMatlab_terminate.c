/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 * File: lenetSynthMatlab_terminate.c
 *
 * MATLAB Coder version            : 4.0
 * C/C++ source code generated on  : 08-Dec-2018 21:01:38
 */

/* Include Files */
#include "lenetSynthMatlab.h"
#include "lenetSynthMatlab_terminate.h"

/* Function Definitions */

/*
 * Arguments    : void
 * Return Type  : void
 */
void lenetSynthMatlab_terminate(void)
{
  /* (no terminate code required) */
}

/*
 * File trailer for lenetSynthMatlab_terminate.c
 *
 * [EOF]
 */
