/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 * File: lenetSynthMatlab_data.c
 *
 * MATLAB Coder version            : 4.0
 * C/C++ source code generated on  : 08-Dec-2018 21:01:38
 */

/* Include Files */
#include "lenetSynthMatlab.h"
#include "lenetSynthMatlab_data.h"

/* Variable Definitions */
float weightsConv1[150];
float biasConv1[6];
float weightsConv2[2400];
float biasConv2[16];
float weightsFC1[48000];
float biasFC1[120];
float weightsFC2[10080];
float biasFC2[84];
float weightsFC3[840];
float biasFC3[10];

/*
 * File trailer for lenetSynthMatlab_data.c
 *
 * [EOF]
 */
