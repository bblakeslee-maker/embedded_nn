/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 * File: sum.h
 *
 * MATLAB Coder version            : 4.0
 * C/C++ source code generated on  : 08-Dec-2018 21:01:38
 */

#ifndef SUM_H
#define SUM_H

/* Include Files */
#include <stddef.h>
#include <stdlib.h>
#include "rtwtypes.h"
#include "lenetSynthMatlab_types.h"

/* Function Declarations */
extern float b_sum(const float x[5]);
extern void c_sum(const float x[150], float y[30]);
extern void d_sum(const float x[30], float y[6]);
extern float e_sum(const float x[6]);
extern void f_sum(const float x[400], float y[80]);
extern void g_sum(const float x[80], float y[16]);
extern float h_sum(const float x[16]);
extern void sum(const float x[25], float y[5]);

#endif

/*
 * File trailer for sum.h
 *
 * [EOF]
 */
